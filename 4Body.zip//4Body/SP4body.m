function [p0,q0]=SP4body(T,N)
% Spectral Galerkin Methods for 4 body problem in 2-dim
% Dr. Lewei Zhao, Mathematics Department, Wayne State University
% zhaoleweimath@gmail.com
% Updated on 08/06/2019
% T is time, N is lengdre polynomial degree
% Random choosing initial value
%p0=4*rand(1,8)-2
%q0=6*rand(1,8)-3

%Test 1 Star (From Prof.Zhifu Xie )
%p0=[-0.55391384867197 -0.39895079845794 1.0936551555351 0 -0.55391558212647 0.39895379682134 0.01417427526245 0];

%q0=[1.0598738926379 1.7699901770118 0 -0.80951135793043 -1.0598738926379 1.7699901770118 0 -2.7304689960932];

% Perturbation test
%p0=p0+0.2;
%q0=q0+0.2;

%p0=p0+[0.2 -0.2 0.2 -0.2 0.2 -0.2 0.2 -0.2];
%q0=q0+[0.2 -0.2 0.2 -0.2 0.2 -0.2 0.2 -0.2];

%p0=p0+[0.2 0 0.2 0 0.2 0 0.2 0];
%q0=q0+[0.2 0 0.2 0 0.2 0 0.2 0];

%p0=p0+[-0.2 sqrt(3)*0.2 -0.2 sqrt(3)*0.2 -0.2 sqrt(3)*0.2 -0.2 sqrt(3)*0.2];
%q0=q0+[-0.2 sqrt(3)*0.2 -0.2 sqrt(3)*0.2 -0.2 sqrt(3)*0.2 -0.2 sqrt(3)*0.2];

% Test 2
%p0=[-1.6115 1.2938 0.7793 -0.7316 1.8009 -1.8622 -0.2450 -0.4738];
%q0=[1.5931 1.7712 -1.8788 -0.0614 -0.3265 0.8779 1.2562 1.5281];

% Test 3
%q0=[2.745 2.7893 -2.0543 2.8236 2.743 -0.0877 1.8017 -2.1487];

% Test 4 Figure 9 theta=3/7pi (different theta chosen from Prof.Zhifu Xie)
%p0=[-0.4908748479 -0.474846875 1.039561987 0 -0.4908732773 0.4748477727 -0.05781386229 0];
%q0=[0.9421633223 2.189470662 0 -1.300537268 -0.9421633223 2.189470662 0 -3.078404055];


% Test 5 Figure 7 theta=4/9pi
p0=[-0.4491532002 -0.5077584354 1.002413363 0 -0.4491265528 0.5077539042 -0.1041336098 0];
q0=[0.886183635 2.574192004 0 -1.721056291 -0.886183635 2.574192004 0 -3.427327717 ];


% Test 6 Figure 6 theta=5/12pi
%p0=[-0.5187341985 -0.4460463326 1.064058961 0 -0.5187107584 0.4460354291 -0.02661400412 0 ];
%q0=[0.9885667998 1.984831768 0 -1.067317853 -0.9885667998 1.984831768 0 -2.902345684];

% Test 7 Figure 
%p0=[-0.5352327448 -0.4256795762 1.078223783 0 -0.5352124256 0.4256692972 -0.00777861305 0];
%q0=[1.0200781 1.878808307 0 -0.9422097516 -1.0200781 1.878808307 0 -2.815406862];

% Initial energy 
H0=0.5*sum(p0.^2)-((q0(1)-q0(3))^2+(q0(2)-q0(4))^2).^(-0.5)-((q0(1)-q0(5))^2+(q0(2)-q0(6))^2).^(-0.5)-((q0(1)-q0(7))^2+(q0(2)-q0(8))^2).^(-0.5)-((q0(3)-q0(5))^2+(q0(4)-q0(6))^2).^(-0.5)-((q0(3)-q0(7))^2+(q0(4)-q0(8))^2).^(-0.5)-((q0(5)-q0(7))^2+(q0(6)-q0(8))^2).^(-0.5);

% Numerical Intergation by p Gauss Points
p=4*N+1;
% Gauss Points and Weights by Dr.Li-lian Wang's code
[X0,W]=legslb(p);

% function values of {phi_i} on Guass points
Base=zeros(p,N);
for i=1:N-1
    Base(:,i)=lepoly(i-1,X0)-lepoly(i+1,X0);
end
Base(:,N)=0.5*(X0+1);

z=ones(N-1,1);
A=2*diag(z,1)-2*diag(z,-1);
A(1,N)=1;
A(N,1)=-1;
A(N-1,N)=0;
A(N,N-1)=0;
A(N,N)=0.5;
k0=0:N-1;
dk=2./(2*k0+1)+2./(2*k0+5);
k1=0:N-3;
zk=-2./(2*k1+5);
% M is mass matrix (phi_i,phi_j)
M=diag(dk)+diag(zk,2)+diag(zk,-2);
M(N-2,N)=0;
M(N,N-2)=0;
M(1,N)=1;
M(N,1)=1;
M(2,N)=1/3;
M(N,2)=1/3;
M(N,N)=2/3;
U=zeros(N);
   
     
An=[2*A  U   U   U   U   U   U   U   U   U   U   U   U   U   U   U;
     U  2*A  U   U   U   U   U   U   U   U   U   U   U   U   U   U;
     U   U  2*A  U   U   U   U   U   U   U   U   U   U   U   U   U;
     U   U   U  2*A  U   U   U   U   U   U   U   U   U   U   U   U;
     U   U   U   U  2*A  U   U   U   U   U   U   U   U   U   U   U;
     U   U   U   U   U  2*A  U   U   U   U   U   U   U   U   U   U;
     U   U   U   U   U   U  2*A  U   U   U   U   U   U   U   U   U;
     U   U   U   U   U   U   U  2*A  U   U   U   U   U   U   U   U;
    -M   U   U   U   U   U   U   U  2*A  U   U   U   U   U   U   U;
     U  -M   U   U   U   U   U   U   U  2*A  U   U   U   U   U   U;
     U   U  -M   U   U   U   U   U   U   U  2*A  U   U   U   U   U;
     U   U   U  -M   U   U   U   U   U   U   U  2*A  U   U   U   U;
     U   U   U   U  -M   U   U   U   U   U   U   U  2*A  U   U   U;
     U   U   U   U   U  -M   U   U   U   U   U   U   U  2*A  U   U;
     U   U   U   U   U   U  -M   U   U   U   U   U   U   U  2*A  U;
     U   U   U   U   U   U   U  -M   U   U   U   U   U   U   U  2*A];
     
   
l=zeros(N,1);
l0=zeros(8*N,1);
l(1)=2;
l(end)=1;


for It=1:T


L=[l0;p0(1)*l;p0(2)*l;p0(3)*l;p0(4)*l;p0(5)*l;p0(6)*l;p0(7)*l;p0(8)*l];
q1x=q0(1);
q1y=q0(2);
q2x=q0(3);
q2y=q0(4);
q3x=q0(5);
q3y=q0(6);
q4x=q0(7);
q4y=q0(8);

dunorm=1;

% P1x is p1x
P1x=zeros(p,1);
% Q1y is q1y
P1y=zeros(p,1);

P2x=zeros(p,1);
P2y=zeros(p,1);
P3x=zeros(p,1);
P3y=zeros(p,1);
P4x=zeros(p,1);
P4y=zeros(p,1);



% Q1x is q1x
Q1x=zeros(p,1);
% Q1y is q1y
Q1y=zeros(p,1);

Q2x=zeros(p,1);
Q2y=zeros(p,1);
Q3x=zeros(p,1);
Q3y=zeros(p,1);
Q4x=zeros(p,1);
Q4y=zeros(p,1);






% Tolarte condition
while dunorm>10^(-14)

F1x=sum(diag(W.*((Q2x+q2x-Q1x-q1x).*((Q2x+q2x-Q1x-q1x).^2+(Q2y+q2y-Q1y-q1y).^2).^(-1.5)+(Q3x+q3x-Q1x-q1x).*((Q3x+q3x-Q1x-q1x).^2+(Q3y+q3y-Q1y-q1y).^2).^(-1.5)+(Q4x+q4x-Q1x-q1x).*((Q4x+q4x-Q1x-q1x).^2+(Q4y+q4y-Q1y-q1y).^2).^(-1.5)))*Base); 

F1y=sum(diag(W.*((Q2y+q2y-Q1y-q1y).*((Q2x+q2x-Q1x-q1x).^2+(Q2y+q2y-Q1y-q1y).^2).^(-1.5)+(Q3y+q3y-Q1y-q1y).*((Q3x+q3x-Q1x-q1x).^2+(Q3y+q3y-Q1y-q1y).^2).^(-1.5)+(Q4y+q4y-Q1y-q1y).*((Q4x+q4x-Q1x-q1x).^2+(Q4y+q4y-Q1y-q1y).^2).^(-1.5)))*Base);    


F2x=sum(diag(W.*((Q1x+q1x-Q2x-q2x).*((Q2x+q2x-Q1x-q1x).^2+(Q2y+q2y-Q1y-q1y).^2).^(-1.5)+(Q3x+q3x-Q2x-q2x).*((Q3x+q3x-Q2x-q2x).^2+(Q3y+q3y-Q2y-q2y).^2).^(-1.5)+(Q4x+q4x-Q2x-q2x).*((Q4x+q4x-Q2x-q2x).^2+(Q4y+q4y-Q2y-q2y).^2).^(-1.5)))*Base); 

F2y=sum(diag(W.*((Q1y+q1y-Q2y-q2y).*((Q2x+q2x-Q1x-q1x).^2+(Q2y+q2y-Q1y-q1y).^2).^(-1.5)+(Q3y+q3y-Q2y-q2y).*((Q3x+q3x-Q2x-q2x).^2+(Q3y+q3y-Q2y-q2y).^2).^(-1.5)+(Q4y+q4y-Q2y-q2y).*((Q4x+q4x-Q2x-q2x).^2+(Q4y+q4y-Q2y-q2y).^2).^(-1.5)))*Base);    

F3x=sum(diag(W.*((Q1x+q1x-Q3x-q3x).*((Q3x+q3x-Q1x-q1x).^2+(Q1y+q1y-Q3y-q3y).^2).^(-1.5)+(Q2x+q2x-Q3x-q3x).*((Q3x+q3x-Q2x-q2x).^2+(Q3y+q3y-Q2y-q2y).^2).^(-1.5)+(Q4x+q4x-Q3x-q3x).*((Q4x+q4x-Q3x-q3x).^2+(Q4y+q4y-Q3y-q3y).^2).^(-1.5)))*Base); 

F3y=sum(diag(W.*((Q1y+q1y-Q3y-q3y).*((Q3x+q3x-Q1x-q1x).^2+(Q1y+q1y-Q3y-q3y).^2).^(-1.5)+(Q2y+q2y-Q3y-q3y).*((Q3x+q3x-Q2x-q2x).^2+(Q3y+q3y-Q2y-q2y).^2).^(-1.5)+(Q4y+q4y-Q3y-q3y).*((Q4x+q4x-Q3x-q3x).^2+(Q4y+q4y-Q3y-q3y).^2).^(-1.5)))*Base);    

F4x=sum(diag(W.*((Q1x+q1x-Q4x-q4x).*((Q4x+q4x-Q1x-q1x).^2+(Q4y+q4y-Q1y-q1y).^2).^(-1.5)+(Q2x+q2x-Q4x-q4x).*((Q2x+q2x-Q4x-q4x).^2+(Q2y+q2y-Q4y-q4y).^2).^(-1.5)+(Q3x+q3x-Q4x-q4x).*((Q4x+q4x-Q3x-q3x).^2+(Q4y+q4y-Q3y-q3y).^2).^(-1.5)))*Base); 

F4y=sum(diag(W.*((Q1y+q1y-Q4y-q4y).*((Q4x+q4x-Q1x-q1x).^2+(Q4y+q4y-Q1y-q1y).^2).^(-1.5)+(Q2y+q2y-Q4y-q4y).*((Q2x+q2x-Q4x-q4x).^2+(Q2y+q2y-Q4y-q4y).^2).^(-1.5)+(Q3y+q3y-Q4y-q4y).*((Q4x+q4x-Q3x-q3x).^2+(Q4y+q4y-Q3y-q3y).^2).^(-1.5)))*Base);    


F=[F1x';F1y';F2x';F2y';F3x';F3y';F4x';F4y';l0]+L;

u1=An\F;


% P1X is function value of p1x on [-1,1]   
P1X=Base*u1(1:N);
% P1Y is function value of p1y on [-1,1]
P1Y=Base*u1(N+1:2*N);

P2X=Base*u1(2*N+1:3*N);
P2Y=Base*u1(3*N+1:4*N);

P3X=Base*u1(4*N+1:5*N);
P3Y=Base*u1(5*N+1:6*N);

P4X=Base*u1(6*N+1:7*N);
P4Y=Base*u1(7*N+1:8*N);


% Q1X is function value of q1x on [-1,1]   
Q1X=Base*u1(8*N+1:9*N);
% Q1Y is function value of q1y on [-1,1]
Q1Y=Base*u1(9*N+1:10*N);

Q2X=Base*u1(10*N+1:11*N);
Q2Y=Base*u1(11*N+1:12*N);

Q3X=Base*u1(12*N+1:13*N);
Q3Y=Base*u1(13*N+1:14*N);

Q4X=Base*u1(14*N+1:15*N);
Q4Y=Base*u1(15*N+1:16*N);




% Discrete L_2 norm
gg=[sum((P1X-P1x).^2.*W)^0.5 sum((P1Y-P1y).^2.*W)^0.5 sum((P2X-P2x).^2.*W)^0.5 sum((P2Y-P2y).^2.*W)^0.5 sum((P3X-P3x).^2.*W)^0.5 sum((P3Y-P3y).^2.*W)^0.5 sum((P4X-P4x).^2.*W)^0.5 sum((P4Y-P4y).^2.*W)^0.5 sum((Q1X-Q1x).^2.*W)^0.5 sum((Q1Y-Q1y).^2.*W)^0.5 sum((Q2X-Q2x).^2.*W)^0.5 sum((Q2Y-Q2y).^2.*W)^0.5 sum((Q3X-Q3x).^2.*W)^0.5 sum((Q3Y-Q3y).^2.*W)^0.5 sum((Q4X-Q4x).^2.*W)^0.5 sum((Q4Y-Q4y).^2.*W)^0.5];
dunorm=max(gg);

P1x=P1X;
P1y=P1Y;
P2x=P2X;
P2y=P2Y;
P3x=P3X;
P3y=P3Y;
P4x=P4X;
P4y=P4Y;

Q1x=Q1X;
Q1y=Q1Y;
Q2x=Q2X;
Q2y=Q2Y;
Q3x=Q3X;
Q3y=Q3Y;
Q4x=Q4X;
Q4y=Q4Y;

end

Q1X=Q1X+q1x;
Q1Y=Q1Y+q1y;
plot(Q1X,Q1Y,'b')

hold on

Q2X=Q2X+q2x;
Q2Y=Q2Y+q2y;
plot(Q2X,Q2Y,'r')

hold on

Q3X=Q3X+q3x;
Q3Y=Q3Y+q3y;
plot(Q3X,Q3Y,'y')

hold on

Q4X=Q4X+q4x;
Q4Y=Q4Y+q4y;
plot(Q4X,Q4Y,'g')

hold on




p0=[u1(N) u1(2*N) u1(3*N) u1(4*N) u1(5*N) u1(6*N) u1(7*N) u1(8*N)]+p0;
q0=[u1(9*N) u1(10*N) u1(11*N) u1(12*N) u1(13*N) u1(14*N) u1(15*N) u1(16*N)]+q0;


end

H=0.5*sum(p0.^2)-((q0(1)-q0(3))^2+(q0(2)-q0(4))^2).^(-0.5)-((q0(1)-q0(5))^2+(q0(2)-q0(6))^2).^(-0.5)-((q0(1)-q0(7))^2+(q0(2)-q0(8))^2).^(-0.5)-((q0(3)-q0(5))^2+(q0(4)-q0(6))^2).^(-0.5)-((q0(3)-q0(7))^2+(q0(4)-q0(8))^2).^(-0.5)-((q0(5)-q0(7))^2+(q0(6)-q0(8))^2).^(-0.5);
eH=abs(H0-H)



